$(document).ready(function() {
 
	
 navigateOwl();
});


function startOwl(){
	
	 var owl = $("#owl-demo");
 
  owl.owlCarousel();
 owl.on('mousewheel', '.owl-stage', function (e) {
    if (e.deltaY>0) {
        owl.trigger('next.owl');
    } else {
        owl.trigger('prev.owl');
    }
    e.preventDefault();
});
 
 /*
   carousel.owlCarousel({
   items : 4,
   lazyLoad : true,
   navigation : true,
   afterAction: function(el){
   //remove class active
   this
   .$owlItems
   .removeClass('active')

   //add class active
   this
   .$owlItems //owl internal $ object containing items
   .eq(this.currentItem + 1)
   .addClass('active')    
    } 
    });
	
	*/
	
	
};

function navigateOwl(){
$(document).keydown(function(e) {
    switch(e.which) {
        case 37: // left
		$("#owl-demo").trigger('owl.prev');
		
        break;

        case 38: // up
        break;

        case 39: // right
		$("#owl-demo").trigger('owl.next');
        break;

        case 40: // down
        break;

        default: return; // exit this handler for other keys
    }
    e.preventDefault(); // prevent the default action (scroll / move caret)
});

}