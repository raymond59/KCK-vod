//    A little bit of data needed to get jsfiddle to fake an ajax request
/*
var fiddleResponse = 'json=' + encodeURIComponent(angular.toJson({
    name: "Dave"
}));
var fiddleHeaders = {
    headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
        }
};
*/
var app = angular.module('app', []);

app.directive("owlCarousel", function() {
	return {
		restrict: 'E',
		transclude: false,
		link: function (scope) {
			scope.initCarousel = function(element) {
			  // provide any default options you want
			  
			  /*
				var defaultOptions = {
				};
				var customOptions = scope.$eval($(element).attr('data-options'));
				// combine the two options objects
				for(var key in customOptions) {
					defaultOptions[key] = customOptions[key];
				}
				// init carousel
				$(element).owlCarousel(defaultOptions);
			  */
			  
			  startOwl();
	  alert("df");
			  
			};
		}
	};
})
.directive('owlCarouselItem', [function() {
	return {
		restrict: 'A',
		transclude: false,
		link: function(scope, element) {
		  // wait for the last item in the ng-repeat then call init
			if(scope.$last) {
				scope.initCarousel(element.parent());
			}
		}
	};
}]);


app.factory('moviesService', function($http, $q) {

    //    Create a class that represents our movies service.
    function moviesService() {
    
        var self = this;
        
        //    Initially the movies is unknown....
        self.movies = null;
        self.url = "https://demo2697834.mockable.io/movies";  
        //    getmovies returns a promise which when fulfilled returns the movies.
        self.getMovies = function() {
            
            //    Create a deferred operation.
            var deferred = $q.defer();
            
            //    If we already have the movies, we can resolve the promise.
            if(self.movies !== null) {
                deferred.resolve(self.movies + " (from Cache!)");
            } else {
                //    Get the movies from the server.
                //$http.post('/echo/json/', fiddleResponse, fiddleHeaders)
                $http.get(self.url)
                
                .success(function(response) {
                
                    self.movies = response.movies;
                    deferred.resolve(response);
					
					
                })
                .error(function(response) {
                    deferred.reject(response);
                });
            }
            
            //    Now return the promise.
            return deferred.promise;
        };
    }
    
    return new moviesService();
});

app.controller('MainController', function ($scope, moviesService) {

    //    We have movies on the code, but it's initially empty...
    $scope.movies = "";
    $scope.showCarou = false;
	$scope.showMovie = false;
    //    We have a function on the scope that can update the movie.
    $scope.updateMovies = function() {
        moviesService.getMovies()
            .then(
                /* success function */
                function(movies) {
                    $scope.movies = movies;
					$scope.showCarou = true;
					
                },
                /* error function */
                function(result) {
                    console.log("Failed to get the movies, result is " + result); 
            });
    };
	
	$scope.updateMovies();

	$scope.showMoviePlayer = function(thisMovie) {
		$scope.selectedMovie = thisMovie;
		//$scope.showMovie = true;
		
	}
	
	});

